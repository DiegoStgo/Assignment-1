package package1;

import java.util.Scanner;

public class WifiDriver {
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Having a problem with internet connection?  This Wifi Diagnosis might help you out.");
		
		System.out.println("First Step: Reboot your computer");
		System.out.println("Are you able to connect to WiFi now?");
		String a = scan.next();
		if ("yes".equals(a)) {
			System.out.println("Congrats!  Rebooting the computer worked!");
			System.exit(0);
		}
		else {
			System.out.println("That's a shame.  Let's try another method.");
		}
		
		System.out.println("Second Step: Reboot your router");
		System.out.println("Are you able to connect to WiFi now?");
		String b = scan.next();
		if ("yes".equals(b)) {
			System.out.println("Congrats!  Rebooting the router worked!");
			System.exit(0);
		}
		else {
			System.out.println("I guess not?  Ah well, let's try something else.");
		}
		
		System.out.println("Third Step: Ensure your router's cables are firmly plugged in.");
		System.out.println("Are you able to connect to the WiFi now?");
		String c = scan.next();
		if ("yes".equals(c)) {
			System.out.println("Congrats!  Plugging in the cables firmly worked!");
			System.exit(0);
		}
		else {
			System.out.println("That sucks.  Onto another method, I suppose.");
		}
		
		System.out.println("Fourth Step: Move your computer closer to your router.");
		System.out.println("Are you able to connect to the WiFi now?");
		String x = scan.next();
		if ("yes".equals(x)) {
			System.out.println("Congrats!  Moving closer to the router worked!");
			System.exit(0);
		}
		else {
			System.out.println("I see.  Only one thing left to try.");
			System.out.println("Fifth Step: Contact your ISP");
			System.out.println("Make sure your ISP is hooked up to your router.");
			System.exit(0);
		}
	}
}
