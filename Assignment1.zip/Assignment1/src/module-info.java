/**
 * 
 */
/**
 * @author J
 *
 */
module Assignment1 {
}